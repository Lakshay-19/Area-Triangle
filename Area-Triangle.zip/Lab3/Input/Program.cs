﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



//Lakshay Punj
//March 6, 2019
//Calculate area of triangle

namespace Input
{
    class Program
    {
        static void Main(string[] args)
        {
            


         //Get inputs from user

            Console.WriteLine("Enter the traingle's base");
            double Base = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter the height");
            double Height = double.Parse(Console.ReadLine());
            
        //Calculation Process
            double Area = ((Base * Height) / 2);
           
        //Final Answer Displayed
            Console.WriteLine("Area = "+ Area);


            Console.ReadKey();


        }
    }
}
